run the following commands one the same directory



To compile all files run "javac *.java"

to run a particular problem run "java problemName"
	for exampale "java problem1"